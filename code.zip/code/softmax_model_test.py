from __future__ import division
import numpy as np
import utils


class SoftMaxModelTest:
    def __init__(self, dataset, numClasses, numFeatures):
        self.datatest = utils.load_dataset(dataset + '/' + dataset + "_test")
        self.datatrain = utils.load_dataset(dataset + '/' + dataset + "_train")
        self.Xtest, self.ytest = self.datatest['X'], self.datatest['y']
        self.Xtrain, self.ytrain = self.datatrain['X'], self.datatrain['y']
        self.num_classes = numClasses
        self.num_features = numFeatures

    def train_error(self, ww):

        # hardcoded for MNIST
        W = np.reshape(ww, (self.num_classes, self.num_features))
        #W = np.reshape(ww, (10, 41))
        yhat = np.argmax(np.dot(self.Xtrain, W.T), axis=1)
        error = np.mean(yhat != self.ytrain)
        return error


    def test_error(self, ww):
        W = np.reshape(ww, (self.num_classes, self.num_features))
        #W = np.reshape(ww, (23, 41))
        yhat = np.argmax(np.dot(self.Xtest, W.T), axis=1)
        error = np.mean(yhat != self.ytest)
        return error


   