import json
import numpy as np
import requests
import os
from softmax_model_obj import SoftMaxModel
import utils
import hashlib

class FLClient:
    def __init__(self, client_id, aggregator_url):
        self.client_id = client_id
        self.aggregator_url = aggregator_url
        # self.local_test_data = np.load('mnist/mnist_test.npy', allow_pickle=True).item()
        self.local_test_data = utils.load_dataset('./client_1_data')
        self.X_test = self.local_test_data['X']
        self.y_test = self.local_test_data['y']

        # Load client-specific training data
        # client_data = np.load(f'mnist/client{client_id}.npy', allow_pickle=True).item()
        self.model = SoftMaxModel(f'./client_1_data', 10)  # 10 classes for MNIST
        self.batch_size = 50

    def calculate_accuracy(self, weights):
        W = np.reshape(weights, (10, 784))  # MNIST: 10 classes × 784 features
        y_pred = np.argmax(np.dot(self.X_test, W.T), axis=1)
        return np.mean(y_pred == self.y_test)
    
    @staticmethod
    def generate_mask(seed, shape):
        np.random.seed(int(hashlib.sha256(seed.encode()).hexdigest(), 16) % (10 ** 8))
        return np.random.normal(0, 0.1, size=shape)


    def train_round(self, global_weights):
        # Local training
        delta, loss = self.model.private_func(global_weights, batch_size=self.batch_size, num_iterations=10000)

        # if np.linalg.norm(delta) > 1:
        #     delta = delta / np.linalg.norm(delta)*5
        max_norm = 5
        delta_norm = np.linalg.norm(delta)
        if delta_norm > max_norm:
           delta = delta * (max_norm / delta_norm)

        
        updated_weights = global_weights + delta
        accuracy = self.calculate_accuracy(updated_weights)

        mask = self.generate_mask(seed=f"mask_{self.client_id}", shape=delta.shape)
        masked_delta = delta

        return masked_delta, loss, accuracy


    def run(self):
          for _ in range(5):
            try:
                # Get global weights
                response = requests.get(f"{self.aggregator_url}/get_weights")
                global_weights = np.array(response.json()['weights'])

                # Train and get metrics
                delta, loss, accuracy = self.train_round(global_weights)

                print(f"Client {self.client_id} sending update. Accuracy: {accuracy:.2%}, Loss: {loss:.4f}")

                # Send update with accuracy
                requests.post(
                    f"{self.aggregator_url}/submit_update",
                    json={
                        'client_id': self.client_id,
                        'delta': delta.tolist(),
                        'loss': float(loss),
                        'accuracy': float(accuracy)
                    }
                )
                
            except Exception as e:
             print(f"Client {self.client_id} error: {str(e)}")


if __name__ == "__main__":
    client = FLClient(
        client_id=int(os.getenv('CLIENT_ID', 0)),
        aggregator_url=os.getenv('AGGREGATOR_URL', 'http://aggregator:5000')
    )
    client.run()