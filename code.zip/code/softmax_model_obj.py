from __future__ import division
from scipy.special import logsumexp
import numpy as np
import utils

iteration = 1

class SoftMaxModel:

    def __init__(self, dataset, numClasses):

        data = utils.load_dataset(dataset)
        self.dataset = dataset
        self.X = data['X']/255.0
        self.y = data['y']
        self.n_classes = numClasses
        self.d = self.X.shape[1] * self.n_classes
        self.lammy = 0.01
        self.alpha = 0.01

    def get_data(self):
        return self.X, self.y

    def soft_func(self, ww, Xbatch, ybatch, batch_size):

        #n=no.of samples, d=no.of features
        num_samples, num_features = Xbatch.shape
        #ww=input parameter, it is reshaped into matrix of dimensions no. of classes, no. of features
        #W = theta matrix(like weights)
        W = np.reshape(ww, (self.n_classes, num_features))

        
        #creates a 2d matrix with samples and classes, initialises it with zero.
        y_true = np.zeros((num_samples, self.n_classes)).astype(bool)
        #setting 1 to the cell, where particular sample belongs to particular class.
        y_true[np.arange(num_samples), ybatch.astype(int)] = 1

        #W.T = Transpose Matrix
        XW = np.dot(Xbatch, W.T)
        

        # Calculate the cost function value
        f = - np.sum(XW[y_true] - logsumexp(XW, axis=1))
        
        # Prevents overflow ,By subtracting the maximum value, we ensure that 
        # the largest exponentiated value will be 0 or negative, which helps prevent overflow when computing exponentials.
        XW = XW - np.max(XW) 
        # calculates the sum of exponentials of each row, return matrix with n no. of rows and 1 column
        denom = np.sum(np.exp(XW), axis=1)
        #np.exp(XW) every elemnet is exponentiated and divided by corresponding rowth element from Z
        hypo = np.exp(XW) / denom[:, None]
        # This step is typically done to handle cases where all elements in a row of XW are very small, resulting in exponentiation underflow
        hypo[np.isnan(hypo)] = 0
        #hypo is hypotheisis vector
        # res= x*(hypothesis-y)
        res = np.dot((hypo - y_true).T, Xbatch)

        # Calculate the gradient value
        #self lammy= regularisation parameter
        g = (1 / batch_size) * res + self.lammy * W
        
        return f, g.flatten()


    def private_func(self, ww, batch_size, num_iterations=1, iter_num=0):
        
 
        ww = np.array(ww)
        total_delta = np.zeros(ww.shape[0])

        for it in range(num_iterations):

            # Define constants and params
            nn, dd = self.X.shape
            #if mini-batch is desired, idx chooses random batches without replacement
            if batch_size > 0 and batch_size < nn:
                idx = np.random.choice(nn, batch_size, replace=False)
            else:
                # Just take the full range
                idx = range(nn)

            f, g = self.soft_func(ww, self.X[idx, :], self.y[idx], batch_size)
            delta = -self.alpha * g
            ww = ww + delta
            total_delta = total_delta + delta 

        return total_delta, f


