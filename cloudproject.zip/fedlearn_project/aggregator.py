from flask import Flask, request, jsonify
import numpy as np
from collections import defaultdict
import hashlib

app = Flask(__name__)
print("hello appu!")
# Global state
global_weights = np.random.rand(10 * 784) / 100.0  # MNIST: 10 classes × 784 features
client_metrics = defaultdict(dict)
num_clients = 2

@app.route('/get_weights', methods=['GET'])
def get_weights():
    return jsonify({'weights': global_weights.tolist()})

@app.route('/submit_update', methods=['POST'])
def submit_update():
    data = request.json
    client_id = data['client_id']

    # Store client metrics
    client_metrics[client_id] = {
        'loss': data['loss'],
        'accuracy': data['accuracy'],
        'delta': np.array(data['delta'])
    }

    # When all clients have reported
    if len(client_metrics) == num_clients:
        aggregate_updates()
        return jsonify({
            'weights': global_weights.tolist(),
            'client_metrics': client_metrics
        })
    return jsonify({'status': 'update received'})

def generate_mask(seed, shape):
    np.random.seed(int(hashlib.sha256(seed.encode()).hexdigest(), 16) % (10 ** 8))
    return np.random.normal(0, 0.1, size=shape)

def aggregate_updates():
    global global_weights, client_metrics

    # Simple averaging of deltas
    deltas = []
    for client_id, metrics in client_metrics.items():
        delta = metrics['delta']
        mask = generate_mask(seed=f"mask_{client_id}", shape=delta.shape)
        unmasked_delta = delta - mask
        deltas.append(unmasked_delta)
    global_weights += np.mean(deltas, axis=0)

    # Print metrics
    print("\n=== Round Metrics ===")
    for client_id, metrics in client_metrics.items():
        print(f"Client {client_id}: Loss={metrics['loss']:.4f}, Accuracy={metrics['accuracy']:.2%}")

    avg_accuracy = np.mean([m['accuracy'] for m in client_metrics.values()])
    print(f"Average Accuracy: {avg_accuracy:.2%}\n")

    # Reset for next round
    client_metrics.clear()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)