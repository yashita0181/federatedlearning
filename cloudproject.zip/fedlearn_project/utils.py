from __future__ import division
import os
import numpy as np



def load_dataset(dataset_name):
    data = np.load(os.path.join(dataset_name + '.npy'))
    n, d = data.shape
    X = data[:, 0:d - 1]
    y = data[:, -1]
    return {"X": X, "y": y}


