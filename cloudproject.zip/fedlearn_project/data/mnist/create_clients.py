import numpy as np


def distribute_data(data, num_clients, distribution):
    num_samples = len(data)
    client_samples = [int(percent * num_samples) for percent in distribution]

    start_idx = 0
    for i in range(num_clients):
        print(client_samples[i])
        end_idx = start_idx + client_samples[i]
        client_data = data[start_idx:end_idx]
        np.save("client" + str(i), client_data)
        start_idx = end_idx


if __name__ == "__main__":
    dataset = "mnist"
    # nums = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    data = np.load(dataset + "_train" + ".npy")

    print(len(data))
    np.random.shuffle(data)

    num_clients = 10

    #  homogeneous distribution
    homo = [1.0 / num_clients] * num_clients

    # heterogeneous distribution
    # # hetero = [0.55, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05]
    # hetero = [0.991, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001]
    first_client_share = 0.75
    hetero = [first_client_share] + [(1.0-first_client_share)/(num_clients-1)]*(num_clients-1)
    print(hetero)

    distribute_data(data, num_clients, hetero)
    for i in range(num_clients):
        real_data=np.load('client'+str(i)+'.npy')
        print(len(real_data))
