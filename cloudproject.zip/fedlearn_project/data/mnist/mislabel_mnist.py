import numpy as np
import os
     
if __name__ == "__main__":
     
    dataset="mnist"
    source=input("Enter the label which has to be poisoned: ")
    target=input("Enter the label into which source has to be poisoned to: ")
    filename = dataset + '_train'

    data = np.load( filename + '.npy')
    #This selects all rows (:) of the last column (-1) of the array data. int(target) - int(source):
    print(len(data))
    data = data[data[:, -1] == str(source)]
    data[:, -1] = target
    print(len(data))

    np.save("mnist_bad_"+source+"_"+target, data)
    print(len(data))
    print(data[:5,-1])

