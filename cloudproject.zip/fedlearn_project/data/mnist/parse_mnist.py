import tensorflow as tf
import numpy as np

def slice_fed():
    # Load MNIST dataset using tensorflow
    (Xtrain, ytrain), (Xtest, ytest) = tf.keras.datasets.mnist.load_data()

    # Flatten the images to 1D (28x28 -> 784)
    Xtrain = Xtrain.reshape(-1, 28*28).astype(np.float32) / 255.0
    Xtest = Xtest.reshape(-1, 28*28).astype(np.float32) / 255.0

    # Client 1 will have classes 0-4 and Client 2 will have classes 5-9
    client_1_mask = np.where((ytrain >= 0) & (ytrain <= 4))  # Client 1: Classes 0-4
    client_2_mask = np.where((ytrain >= 5) & (ytrain <= 9))  # Client 2: Classes 5-9

    # Data for Client 1 (classes 0-4)
    Xtrain_client_1 = Xtrain[client_1_mask]
    ytrain_client_1 = ytrain[client_1_mask]
    data_client_1 = np.hstack((Xtrain_client_1, np.reshape(ytrain_client_1, (len(ytrain_client_1), 1))))
    np.save("client_1_data", data_client_1)

    # Data for Client 2 (classes 5-9)
    Xtrain_client_2 = Xtrain[client_2_mask]
    ytrain_client_2 = ytrain[client_2_mask]
    data_client_2 = np.hstack((Xtrain_client_2, np.reshape(ytrain_client_2, (len(ytrain_client_2), 1))))
    np.save("client_2_data", data_client_2)

    # Prepare the test set (for both clients, but for simplicity, storing it as a whole here)
    test_slice = np.hstack((Xtest, np.reshape(ytest, (len(ytest), 1))))
    np.save("mnist_test", test_slice)

    print("Data saved for Client 1 and Client 2.")

if __name__ == "__main__":
    slice_fed()
