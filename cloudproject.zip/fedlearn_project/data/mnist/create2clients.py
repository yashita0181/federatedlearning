import numpy as np

# Load the original MNIST training dataset
data = np.load('data/mnist/mnist_train.npy', allow_pickle=True).item()
X = data['X']
y = data['y']

# Split based on class labels
client_1_mask = (y >= 0) & (y <= 4)
client_2_mask = (y >= 5) & (y <= 9)

client_1_data = {
    'X': X[client_1_mask],
    'y': y[client_1_mask]
}

client_2_data = {
    'X': X[client_2_mask],
    'y': y[client_2_mask]
}

# Save to new .npy files
np.save('client_1_data.npy', client_1_data)
np.save('client_2_data.npy', client_2_data)

print("Data split and saved as client_1_data.npy and client_2_data.npy")
